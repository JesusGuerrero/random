<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'fiaonlin_wordpress');

/** MySQL database username */
define('DB_USER', 'fiaonlin_wpuser');

/** MySQL database password */
define('DB_PASSWORD', 'cyqllctz07');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '6Tg3YowZ9utY; 8&L[~UwS(;n u_lBQbmZ?DF(|!I/- 5L 2S?6i*FR$J/I>o:n-');
define('SECURE_AUTH_KEY',  'hw/Mt:wQ;!vS= =wVwILlET2?AL9-{+tG.#xsuZ}#j?}-8V>l.oe$8gO#.LMH}uE');
define('LOGGED_IN_KEY',    '}2Yp-AA+[E&%8B|!s1^[^[~P+][]Qp2W_7-9!,+Qw6Uc-J}?4Z$=e{/b)#|RF?O1');
define('NONCE_KEY',        'jT[hd*leB/00UVxlTQ-&iUk5-1Bv>cFHE^tCl~!D!-/bLx~%pi~g(k(X{,wOs{]u');
define('AUTH_SALT',        'FGJ0Kxb/f-~cqB.tqf38OB>$o7mSVd^~|GPBkUeFbuUBhn 1A{EY~}#N5XA?/-C7');
define('SECURE_AUTH_SALT', '|Xszw-x#(uijXu=Ie}D(nq0$%eoXqV&|8R*VnAV.i3/1HzEikF3pMeFS!Mt>H;Va');
define('LOGGED_IN_SALT',   'RQqC#Kg~5V1C`dNVV4e,p{w_)|-/#SSEPBjt8x=#G-[M@N_?W9yQn7_$-9S-Vl+O');
define('NONCE_SALT',       '[u|tAHqX?R_{Mwu3,dn-v+3 ~6+kMeM|5d7`.kwM{@HJ+G,}t{.;I.0|<smb8M`S');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
