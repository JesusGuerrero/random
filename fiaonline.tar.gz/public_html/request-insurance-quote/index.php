<?php
$email = "";
foreach( $_REQUEST as $key=>$val )
{
	if( is_array( $val ) && preg_match("#quote#", $key)  )
	{
		$type = $key;
		foreach( $val as $k=>$v )
		{
			if( is_array( $v ) )
			{
					$email .= $k."<br/>";
					foreach( $v as $ky=>$vl )
					{
						$email .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . strtoupper( str_replace("_", " ", $ky) ). ": " . $vl."<br/>\n";
					}
			}else
			{
				$email .= strtoupper( str_replace("_", " ", $k) ). ": " . $v."<br/>\n";
			}	
		}
	}
}
// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Additional headers
$headers .= "To: Jesus Fernandez <jmfernandez@fia-online.com>\r\n";
$headers .= 'Bcc: Jesus Rocha <jesus@computerenchiladas.com>' . "\r\n";
$headers .= 'From: FIA-ONLINE.COM <no-reply@fia-online.com>' . "\r\n";
mail("", "NEW " .$type ." REQUEST", $email, $headers );

header( "Location: http://www.fia-online.com/get-a-quote/?quoted=true" )
?>
